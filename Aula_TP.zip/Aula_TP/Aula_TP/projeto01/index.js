import chalk from 'chalk';
import fs from 'fs';

function extraiLinks(texto) {
    const regex = /\[([^\]]*)\]\((https?:\/\/[^$#\s].[^\s]*)\)/gm //regex é expressão regular, filtro com o tipo de dado que se pede tipo cpf
    const arrayResultados = [];

    let temp; 
    while((temp = regex.exec(texto))!= null) {
        arrayResultados.push({ [temp[1]] : [temp[2]]})
    }
    return arrayResultados.length === 0 ? "Não há links" : arrayResultados; //ternário, se o resultado for 0 escreve a mensagem
}

function trataErro(erro){ 
    throw new Error(chalk.bgRed(erro.code, "ARQUIVO NÃO ENCONTRADO!")); //se der erro vai pintar de vermelho
}


async function pegaArquivo(caminhoDoArquivo) { //promessa assincrona, retorna quand concluir
    try{    
        const texto = await fs.promises.readFile(caminhoDoArquivo,'utf-8')  //retorno que chega na conclusão
        return(extraiLinks(texto))
    } 
    catch(erro) {  //manupulando o erro
      trataErro(erro)
    }
}

export default pegaArquivo;



